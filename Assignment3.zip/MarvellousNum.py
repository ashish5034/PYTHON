def ChkPrime(numberList):
    ansList = []
    for num in numberList :
        if num == 0 or num == 1 :
            continue
        for i in range(2, num // 2 + 1) :
            if num % i == 0 :
                break
        else:
            ansList.append(num)
            
    return ansList   