def main():
    for i in range(2,21,2):
        print(i, end=" ")
if __name__ == "__main__":
    main()