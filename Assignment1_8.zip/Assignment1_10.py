def main():
    print("Enter name: ")
    name = input()
    print(len(name))
if __name__ == "__main__":
    main()