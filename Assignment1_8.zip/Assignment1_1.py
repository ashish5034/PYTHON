def Fun():
    print("Hello from Fun")


def main():
    Fun()
    
if __name__ == "__main__":
    main()