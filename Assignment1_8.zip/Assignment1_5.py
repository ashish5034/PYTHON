def main():
    i=10
    while(i>=1):
        print(i,end=" ")
        i=i-1
    
if __name__ == "__main__":
    main()