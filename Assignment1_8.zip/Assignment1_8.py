def main():
    for i in range(5):
        print("*", end=" ")
if __name__ == "__main__":
    main()
    